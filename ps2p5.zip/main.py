#comment input
i = float(input("Enter amount of item "))
d = float(input("Enter discount in decimal form "))

#Process phase
s = d * i
p = i * (1-d)

#Output
print("You saved ", s)
print("The total after your discount is ", p)