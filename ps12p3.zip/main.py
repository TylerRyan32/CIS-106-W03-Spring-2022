def getInput():
  user_input = input("Enter comma-separated values: ")

  return user_input

def process(user_input):
  data = user_input.split(',')

  for i in range(len(data)):
    data[i] = data[i].strip()

  return data

def output(data):
  for element in data:
    print(element)

def main():
  user_input = getInput()
  
  data = process(user_input)
  
  output(data)

main()