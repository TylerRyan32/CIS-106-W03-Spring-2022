class Employee_Bonus:
    def _init_(self, salary, rate):
        self.salary = salary
        self.rate = rate

    def calculate_bonus(self):
        return self.salary * self.rate



class manager:
    def _init_(self, first_name, last_name, district_code, enrolled_credits):

        self.first_name = first_name
        self.last_name = last_name
        self.district_code = district_code
        self.enrolled_credits = enrolled_credits

        pass

    def tuition_owned(self):

        if self.district_code == "I":

            tut = 250.0

        else:

            tut = 500.0

        return tut


e1 = Employee_Bonus(500, 4)

print("The employee bonus is ", e1.calculate_bonus())

print()

s1 = manager("Hilbert", "Stone", "I", 20)

print("First name: ", s1.first_name)
print("Last name: ", s1.last_name)
print("Tuition owned is: ", s1.tuition_owned())