
name = input("Enter employees last name: ")
salary = int(input("Enter the employees salary: "))
level = int(input("Enter the job level: "))

if level >= 10:
  bonusrate = 0.25
elif level >= 5:
  bonusrate = 0.20
else:
  bonusrate = 0.10

bonus = salary * bonusrate

print("Employee last name: ", name)
print("Employees bonus: ", bonus)
