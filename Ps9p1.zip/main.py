def compdisrate(qty,price):
  total = float(qty) * float(price)
  discount = float(total) * float(0.10)
  if total > 1000.00:
    total = 0.90 * total
  else:
    total = total
  return total, discount

qty = float(input("Enter quantity"))
price = float(input("Enter price"))

total, discount = compdisrate(qty,price)

print("Discount amount: ", discount)
print("Total price after discount: ", total)