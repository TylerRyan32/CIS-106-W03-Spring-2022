f = open("p5d.txt", "r")

#initialize counters and sums to 0
c = 0.0
tot_tuit = 0.0

#get first data line
name = str(f.readline().rstrip('\n'))

while name != "":
    dc = str(f.readline().rstrip('\n'))
    if dc == "I" :
      cpc = 250.00
    else:
      cpc = 500.00
    credit = int(f.readline())

    tuit = cpc * credit
    
    #sum and count - in the loop
    tot_tuit = tot_tuit + tuit
    c = c + 1

    #display a line of data
    print("Name is:       ", name)
    print("Credits:       ", credit)
    print("Tuition:       ", tuit)

    #get next data
    name = str(f.readline().rstrip('\n'))

#after the loop
#final caculations
#display them and sums and counts
print("Sum of all Tuition:  ", tot_tuit)
print("Number of Students:  ", c)