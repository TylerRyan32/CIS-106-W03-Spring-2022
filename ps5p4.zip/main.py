counter = 0

response = input("Would you like to caculate an employees gross pay Yes or No")

while response == "Yes":
  counter = counter + 1
  lastname = input("Enter employee last name")
  hours = float(input("Enter hours worked"))
  payrate = float(input("Enter employees rate of pay"))
  grosspay = hours * payrate
  if hours > 40:
    grosspay = (hours - 40)*(payrate * 1.5) + grosspay
  print(lastname, " has gross pay of ", grosspay)
  response = input("Would you like to caculate an employees gross pay Yes or No")

print("Number of employees ", counter)

