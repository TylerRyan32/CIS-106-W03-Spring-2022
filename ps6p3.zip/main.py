f = open("p3d.txt", "r")

#initialize counters and sums to 0
c = 0.0
totbon = 0.0

#get first data line
name = str(f.readline().rstrip('\n'))

while name != "":
    sal = float(f.readline())
    if sal > 100000.00:
        rate = 0.20
    elif sal > 50000.00:
        rate = 0.15
    else:
        rate = 0.10

    bonus = sal * rate
    total = bonus + sal
    #sum and count - in the loop
    totbon = totbon + bonus
    c = c + 1

    #display a line of data
    print("Name is:         ", name)
    print("Salary is:       ", sal)
    print("Bonus is:        ", bonus)

    #get next data
    name = str(f.readline().rstrip('\n'))

#after the loop
#final caculations
#display them and sums and counts
print("Sum of all Bonuses:  ", totbon)
print("Number of Salarys:    ", c)
