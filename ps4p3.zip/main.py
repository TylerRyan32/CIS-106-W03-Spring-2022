
principle = int(input("Enter the principle amount of a CD"))
year = int(input("Enter the year to maturity"))

if principle > 100000 and year == 5:
  intrate = 0.06
elif principle > 50000 and year == 10:
  intrate = 0.05
elif principle > 50000 and year == 5:
  intrate = 0.04
else:
  intrate = 0.02

firstyear = principle * intrate

print("Principle:                          ", principle)
print("Interest rate:                      ", intrate)
print("Interest amount for the first year: ", firstyear)