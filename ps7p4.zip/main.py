def payrate(jobcode):
  if jobcode == "L":
    payrate = 25
  elif jobcode == "A":
    payrate = 30
  elif jobcode == "J":
    payrate = 50
  return payrate

def grosspay(hours,payrate):
  grosspay = payrate * hours
  return grosspay

name = str(input("Enter name of employee: "))
jobcode = str(input("Enter the Job Code:     "))
hours = float(input("Enter their total hours: "))

payrate = payrate(jobcode)
grosspay = grosspay(hours,payrate)

print("Employee name: ", name)
print("Gross pay:     ", grosspay)