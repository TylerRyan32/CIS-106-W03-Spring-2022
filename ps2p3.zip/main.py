#comment input
w = float(input("Enter the width of the rectangle"))
l = float(input("Enter the length of the rectangle"))

#Process phase
a = w * l
c = (2 * w) + (2 * l)

#output
print ("The area of the rectangle is ", a)
print ("The circumference  is ", c)