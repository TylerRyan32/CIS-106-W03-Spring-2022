response = input("Would you like program the square footage? ")

while response == "yes":
  L = float(input("Enter the length:"))
  W = float(input("Enter the width:"))
  H = float(input("Enter the height:"))
  def sqfoot(L,W,H):
    sqfoot = (2*L*W)+(2*L*H)+(2*W*H)
    return sqfoot
    
  sqfoot = sqfoot(L,W,H)
  gallons = sqfoot / 50

  print("Gallons needed to paint: ", gallons)
  response = input("Would you like program the square footage? ")
  