#comment input
Q = float(input("Enter the quantity "))
P = float(input("Enter the price per unit "))

#Process phase
X = Q * P

#Output
print ("The extended price is ", X)