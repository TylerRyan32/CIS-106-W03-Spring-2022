def batavg(hit,atbat):
  avg = float(hit) / float(atbat)
  return avg

name = str(input("Enter the players name: "))
hit = float(input("Ener the number of hits: "))
atbat = float(input("Enter the number of at bats: "))

avg = batavg(hit,atbat)

print("Players name:    ", name)
print("Batting average: ", avg)