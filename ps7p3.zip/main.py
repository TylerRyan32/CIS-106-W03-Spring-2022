def mpg(miles,gal):
  mpg = float(miles) / float(gal)
  return mpg

def cost(gal):
  cost = float(gal) * 2.5
  return cost

city = str(input("Enter the name of destination: "))
miles = input("Enter the number of miles:       ")
gal = input("ENter the number of gallons:     ")

mpg = mpg(miles,gal)
cost = cost(gal)

print(" ",city)
print("Miles: ", miles)
print("Cost:  ", cost)
print("MPG:   ", mpg)
