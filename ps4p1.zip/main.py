
qty = int(input("Enter the quantity of widgets: "))

if qty > 10000:
  price = 10
elif qty > 5000:
  price = 20
else:
  price = 30

extprice = qty * price
tax = float(extprice) * 0.07
total = extprice + tax

print("Extended price: ",extprice)
print("Tax is:         ", tax)
print("Total is:",total)