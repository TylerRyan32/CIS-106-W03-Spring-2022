def comptotalavg(ascore,bscore,cscore,hc):
  total = float(ascore) + float(bscore) + float(cscore)
  avg = float(total) / 3
  HCavg = avg + hc
  return avg, HCavg

name = str(input("Enter bowlers name: "))
hc = float(input("Enter bowlers handicap: "))
ascore = float(input("Enter the score for Game 1: "))
bscore = float(input("Enter the score for Game 2: "))
cscore = float(input("Enter the score for Game 3: "))

avg, HCavg = comptotalavg(ascore,bscore,cscore,hc)

print("Bowlers name:                ", name)
print("Average score:               ", avg)
print("Average score with Handicap: ", HCavg)