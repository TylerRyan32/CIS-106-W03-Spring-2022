response = input("Would you like program the price of tickets? ")
totalprice = 0.0

while response == "yes":
  name = str(input("Enter name: "))
  miles = float(input("miles from Chicago: "))
  def trainprice(miles):
    if miles > 29:
      tickprice = 12
    elif miles > 19:
      tickprice = 10
    elif miles > 9:
      tickprice = 8
    else:
      tickprice = 5
    return tickprice

  tickprice = trainprice(miles)
  totalprice = totalprice + tickprice

  response = input("Would you like program the price of tickets? ")

print("Price of all tickets: ", totalprice)
  
  
  
      
    