books = input("Enter number of books")
bookcost = input("Enter cost per book")

order = float(books) * float(bookcost)

if order > 50.00:
  shipcost = 0
else: 
  shipcost = 25

print("Order: $", order)
print("Shipping cost: $", shipcost)
