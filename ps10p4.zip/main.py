def displaynames(lastn,avg):
  for i in lastn, avg:
    print(i)
  for y in avg:
    print(y)

def displayr(lastn,avg):
  l = len(lastn)
  print("Arrays in order")
  for y in range (0,l,1):
    print(lastn[y],avg[y])
  print("Arrays in Reverse Order")
  for y in range (l-1,-1,-1):
    print(lastn[y],avg[y])

f = open("Battingavg.txt", "r")

def seqsearch(lastn, sname):
  l = len(lastn)
  i = -1
  for y in range (0,l,1):
    if lastn[y]== sname:
      i = y
  return i

lastname = f.readline()
lastn = []
avg = []
while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  avg.append(s)
  lastname = f.readline()
f.close 
displaynames(lastn,avg)
displayr(lastn,avg)
response = input("Do you want to do this program Yes or No")
while response == "Yes":
  sname = input("Enter name to search for")
  i = seqsearch(lastn, sname)
  if i == -1:
    print(sname, " not in the array")
  else: 
    print(lastn[i], " Average of ", avg[i])

  response = input("Do you want to do this program Yes or No")