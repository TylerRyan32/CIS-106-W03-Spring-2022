def comptottax(qty, price):
  total = qty * price
  tax = 0.070 * total
  return total, tax

qty = float(input("Enter quantity of an item: "))
price = float(input("Enter price per item: "))

total, tax = comptottax(qty, price)

print("Total is:      ", total)
print("With a tax of: ", tax)
