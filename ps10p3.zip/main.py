def displaynames(lastn,score):
  for i in lastn, score:
    print(i)
  for y in score:
    print(y)

def displayr(lastn,score):
  l = len(lastn)
  print("Arrays in order")
  for y in range (0,l,1):
    print(lastn[y],score[y])
  print("Arrays in Reverse Order")
  for y in range (l-1,-1,-1):
    print(lastn[y],score[y])

def hilow(lastn,score):
  l = len(lastn)
  hiscore= -1.0
  lowscore= 99999999.99
  for y in range (0,l,1):
    if float(score[y])> float(hiscore):
      hiindex = y
      hiscore = score[y]

    if float(score[y])< float(lowscore):
      loindex = y
      lowscore = score[y]

  print("highest score", lastn[hiindex], score[hiindex])
  print("lowest score", lastn[loindex], score[loindex])
  

f = open("LNscores.txt", "r")

lastname = f.readline()
lastn = []
score = []
while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  score.append(s)
  lastname = f.readline()
f.close 
displaynames(lastn,score)
displayr(lastn,score)
hilow(lastn,score)