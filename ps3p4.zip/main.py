name = input("Enter name of appliance: ")
app = float(input("Cost of the appliance: "))

if app > 1000.00:
  warcost = 0.1 * float(app)
else:
  warcost = 0.05 * float(app)

total = app + warcost

print(name)
print("Cost of the appliance: ", app)
print("Cost of the warranty:  ", warcost)
print("The total is:          ",total)