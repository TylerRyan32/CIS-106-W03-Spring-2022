response = input("Would you like to compute the next months forecast? ")


while response == "Yes":
  name = str(input("Enter name: "))
  month = str(input("Enter month: "))
  sales = float(input("Enter sales: "))

  def nmsales(month,sales): 
    if month == "January" "February" "March":
      fp = 0.10
    elif month == "April" "May" "June":
      fp = 0.15
    elif month == "July" "August" "September":
      fp = 0.20
    elif month == "October" "November" "December":
      fp = 0.25
    
    nmsales = sales*(1 + fp)
    return nmsales

  nmsales = nmsales(month,sales)
    

  print("Next months sales: ", nmsales)
  
  response = input("Would you like to compute the next months forecast? ")
  