#comment input
N = input("Enter last name of student")
C = input("Enter number of credits taken")

#Process phase
t = (int(C) * 250 + 100)


#Output
print(N)
print("Their total tuition is ", t)