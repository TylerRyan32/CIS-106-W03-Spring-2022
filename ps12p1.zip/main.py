

name = input("Please enter full name")

l = name.split() 

for word in l:
  word = word.strip

if len(l)==1:
  print("You only gave first name, please provide full name with spaces")
else:
  print("Printing your name in the format of (Lastname F) where F is first initial of the the firstname :")
  print("{} {}".format(l[1],l[0][0]))