def tuition(hours,code):
  if code == "I":
    price = 250
  elif code == "O":
    price = 550

  tuition = float(hours) * price
  return tuition

name = str(input("Enter students name:  "))
hours = float(input("Enter credit hours: "))
code = str(input("Enter district code:  "))

tuition = tuition(hours,code)

print("Student name: ", name)
print("Tuition owed: ", tuition)
