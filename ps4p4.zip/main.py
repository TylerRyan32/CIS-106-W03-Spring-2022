
tickets = int(input("Enter the number of concert tickets: "))

if tickets >= 25:
  tickprice = 50
elif tickets >= 10:
  tickprice = 60
elif tickets >= 5:
  tickprice = 70
else:
  tickprice = 75

total = tickprice *  tickets

print("Number of tickets: ", tickets)
print("Price per ticket:  ", tickprice)
print("Total:             ", total)