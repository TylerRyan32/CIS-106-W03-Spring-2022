#comment input
N = input("Enter name of worker")
h = float(input("Enter hours worked"))
p = float(input("Enter pay rate"))

#Process phase
G = h * p

#Output
print(N)
print("Their gross pay is ", G)