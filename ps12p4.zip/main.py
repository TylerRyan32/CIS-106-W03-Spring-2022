
def repeatShift(line):

  noofchar = int(input("Enter number of characters to print in each line: "))

  noofline = int(input("Enter number of lines to print: "))

  scrdirection = str(input("Enter scroll direction of line: Right: r | Left: l ->")



  if scrdirection == "r":
    shift = ""
  elif scrdirection == "l":
    shift = " " * (noofline -1)


  counter = 0


  for i in range(noofline):

    print(shift, end='')


    if scrdirection =="r":
      shift += " "
    elif scrdirection == "l":
      shift = shift[:-1]


    for j in range(noofchar):

      print(line[counter], end='')

      counter = (counter + 1) % len(line)

    print()


if __name__ == '__main__':

  line = input("Enter the line of text: ")

  repeatshift(line)

  
