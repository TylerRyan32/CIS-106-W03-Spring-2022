def comptotalavg(ascore,bscore,cscore):
  total = float(ascore) + float(bscore) + float(cscore)
  avg = float(total) / 3
  return total, avg

ascore = float(input("Enter the score for Exam A: "))
bscore = float(input("Enter the score for Exam B: "))
cscore = float(input("Enter the score for Exam C: "))

total, avg = comptotalavg(ascore,bscore,cscore)

print("Total points: ", total)
print("Average score: ", avg)