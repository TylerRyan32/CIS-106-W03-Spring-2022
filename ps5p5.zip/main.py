counter = 0

response = input("Would you like to caculate a discount Yes or No")

while response == "Yes":
  counter = counter + 1
  qty = float(input("Enter the quantity of an item"))
  price = float(input("Enter the price per item"))
  extprice = qty * price
  if extprice > 10000.00:
    discount = 0.25 * extprice
  else:
    discount = 0.10 * extprice
  total = extprice - discount
  print("The extended price is: ", extprice)
  print("The discount is: ", discount)
  print("The total is: ", total)
  response = input("Would you like to caculate a discount Yes or No")

print("Number of discounts caculated: ", counter)