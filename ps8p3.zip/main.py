response = input("Would you like program the price of vehicle? ")

while response == "yes":
  make = str(input("Make of automobile: "))
  model = str(input("Model of automobile: "))
  electric = str(input("Electric vehicle code: "))
  price = float(input("MSRP of automobile: "))
  def otdprice(make,model,electric,price):
    if electric == "y":
      percentoff: 0.30
    elif electric =="n":
      percentoff: 0.05
    
    newMSRP = price * (1 - percentoff)
    return newMSRP
  print("New MSRP: ", newMSRP)
  response = input("Would you like program the price of vehicle? ")