def comission(sales):
  if sales > 100000.00:
    comission = 0.10 * sales
  else:
    comission = 0.05 * sales
  target = float(sales) * 1.05
  return comission, target

name = str(input("Enter name of sales person: "))
sales = float(input("Enter sales: "))

comission, target = comission(sales)

print("Salesperson name:  ", name)
print("Commision:         ", comission)
print("Next years target: ", target)
