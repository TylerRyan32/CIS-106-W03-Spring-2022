response = input("Would you like program the  assessed value?")
totvalue = 0.0

while response == "yes":
  c = str(input("Enter the county of the home: "))
  m = float(input("Enter market value of home: "))
  if c =="cook":
    avp = 0.90
  elif c =="dupage":
    avp = 0.80
  elif c =="mchenry":
    avp = 0.75
  elif c =="kane":
    avp = 0.60
  else:
    avp = 0.70
    
  def AssessedValue(m,avp):
    AV = m * avp
    return AV
  
  AV = AssessedValue(m,avp)
  totvalue = totvalue + AV

  print("Assessed Value: ", AV)
  response = input("Would you like program the  assessed value?")

print("Total of all assessed values: ", totvalue)
    
    